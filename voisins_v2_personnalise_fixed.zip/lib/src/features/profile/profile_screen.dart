import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ProfileScreen extends StatefulWidget{ const ProfileScreen({super.key}); @override State<ProfileScreen> createState()=>_ProfileScreenState(); }
class _ProfileScreenState extends State<ProfileScreen>{
  final _name=TextEditingController(); final _city=TextEditingController(); final _bio=TextEditingController();
  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async {
    final sb = Supabase.instance.client; final me = sb.auth.currentUser?.id; if (me==null) return;
    final row = await sb.from('profiles').select().eq('id', me).maybeSingle();
    if (row!=null){ _name.text = row['full_name']??''; _city.text=row['city']??''; _bio.text=row['bio']??''; setState((){}); }
  }
  Future<void> _save() async {
    final sb = Supabase.instance.client; final me = sb.auth.currentUser!.id;
    await sb.from('profiles').upsert({'id': me, 'full_name': _name.text, 'city': _city.text, 'bio': _bio.text});
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Profil enregistré')));
  }
  @override Widget build(BuildContext context){
    return SingleChildScrollView(padding: const EdgeInsets.all(16), child: Column(children:[
      TextField(controller:_name, decoration: const InputDecoration(labelText:'Nom complet')),
      const SizedBox(height:8),
      TextField(controller:_city, decoration: const InputDecoration(labelText:'Ville')),
      const SizedBox(height:8),
      TextField(controller:_bio, decoration: const InputDecoration(labelText:'Bio')),
      const SizedBox(height:16),
      FilledButton(onPressed: _save, child: const Text('Enregistrer'))
    ]));
  }
}
