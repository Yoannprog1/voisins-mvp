import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class RequestDetailScreen extends StatefulWidget{
  final String id; const RequestDetailScreen({super.key, required this.id});
  @override State<RequestDetailScreen> createState()=>_RequestDetailScreenState();
}
class _RequestDetailScreenState extends State<RequestDetailScreen>{
  Map<String,dynamic>? item;
  final _msg = TextEditingController(); final _amount = TextEditingController();
  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async { final data = await Supabase.instance.client.from('service_requests').select().eq('id', widget.id).maybeSingle(); setState(()=> item=data); }
  @override Widget build(BuildContext context){
    final r=item; if(r==null) return const Scaffold(body: Center(child:CircularProgressIndicator()));
    return Scaffold(appBar: AppBar(title: Text(r['title']??'Demande')), body: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
      Text('${(r['budget']??0).round()} €', style: Theme.of(context).textTheme.headlineSmall),
      const SizedBox(height:8),
      Row(children:[ const Icon(Icons.place_outlined), SizedBox(width:4), Text(r['city']??''), SizedBox(width:12), Chip(label: Text(r['category']??'')) ]),
      const SizedBox(height:12), Text(r['description']??''),
      const Divider(height:32),
      const Text('Faire une offre'), const SizedBox(height:8),
      TextField(controller:_amount, decoration: const InputDecoration(labelText:'Montant proposé (€)')),
      const SizedBox(height:8),
      TextField(controller:_msg, decoration: const InputDecoration(labelText:'Message')),
      const Spacer(),
      SizedBox(width: double.infinity, child: ElevatedButton.icon(icon: const Icon(Icons.send), label: const Text('Envoyer l\'offre'), onPressed: () async {
        final sb = Supabase.instance.client; final me = sb.auth.currentUser!.id;
        await sb.from('offers').insert({'request_id': widget.id, 'by_user': me, 'message': _msg.text, 'amount': double.tryParse(_amount.text)??0 });
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Offre envoyée')));
      }))
    ])));
  }
}
