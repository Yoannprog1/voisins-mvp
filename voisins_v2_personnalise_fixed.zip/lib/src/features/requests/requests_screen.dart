import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/data/supabase_helpers.dart';

class RequestsScreen extends StatefulWidget{ const RequestsScreen({super.key}); @override State<RequestsScreen> createState()=>_RequestsScreenState(); }
class _RequestsScreenState extends State<RequestsScreen>{
  List<Map<String,dynamic>> _items=[];
  @override void initState(){ super.initState(); _refresh(); }
  Future<void> _refresh() async { final data = await fetchWithFilters(table: 'service_requests'); setState(()=> _items=data); }
  @override Widget build(BuildContext context){
    return RefreshIndicator(onRefresh: _refresh, child: ListView.builder(padding: const EdgeInsets.all(12), itemCount:_items.length, itemBuilder: (_,i){
      final r=_items[i];
      return Card(child: ListTile(title: Text(r['title']??''), subtitle: Text('${r['city']??''} • ${r['category']??''}'), trailing: Text('${(r['budget']??0).round()} €'), onTap: ()=> GoRouter.of(context).go('/request/${r['id']}')));
    }));
  }
}
