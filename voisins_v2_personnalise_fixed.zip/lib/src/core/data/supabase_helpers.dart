import 'package:supabase_flutter/supabase_flutter.dart';

final sb = Supabase.instance.client;

Future<List<Map<String,dynamic>>> fetchWithFilters({
  required String table,
  String? q,
  String? category,
  String? city,
  String? ownerColumn,
}) async {
  var query = sb.from(table).select();
  if (q != null && q.isNotEmpty) {
    query = query.ilike('title', '%$q%');
  }
  if (category != null && category.isNotEmpty) {
    query = query.eq('category', category);
  }
  if (city != null && city.isNotEmpty) {
    query = query.ilike('city', city);
  }
  final data = await query.order('created_at', ascending: false);
  return (data as List).cast<Map<String, dynamic>>();
}
