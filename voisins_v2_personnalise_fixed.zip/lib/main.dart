import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'src/app.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final cfg = await rootBundle.loadString('assets/app_config.json');
  final j = json.decode(cfg);
  await Supabase.initialize(url: j['supabaseUrl'], anonKey: j['supabaseAnonKey']);
  runApp(const AppRoot());
}
