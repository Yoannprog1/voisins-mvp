import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class User {
  final int id;
  final String email;
  final String name;
  final String password; // NOTE: stocké en clair pour MVP local (à remplacer)

  User({required this.id, required this.email, required this.name, required this.password});

  Map<String, dynamic> toJson() => {'id': id, 'email': email, 'name': name, 'password': password};

  static User fromJson(Map<String, dynamic> j) =>
      User(id: j['id'], email: j['email'], name: j['name'], password: j['password']);
}

class AuthService extends ChangeNotifier {
  static const _usersKey = 'users_json';
  static const _currentKey = 'current_user_id';
  late SharedPreferences _sp;
  List<User> _users = [];
  User? _current;

  User? get currentUser => _current;

  Future<void> init() async {
    _sp = await SharedPreferences.getInstance();
    final usersStr = _sp.getString(_usersKey);
    if (usersStr != null && usersStr.isNotEmpty) {
      final List list = jsonDecode(usersStr);
      _users = list.map((e) => User.fromJson(e)).toList().cast<User>();
    }
    final id = _sp.getInt(_currentKey);
    if (id != null) {
      _current = _users.where((u) => u.id == id).firstOrNull;
    }
  }

  Future<String?> signup(String email, String name, String password) async {
    if (_users.any((u) => u.email == email)) return 'Cet email est déjà utilisé.';
    final id = _users.isEmpty ? 1 : (_users.map((e) => e.id).reduce((a, b) => a > b ? a : b) + 1);
    final u = User(id: id, email: email, name: name, password: password);
    _users.add(u);
    await _persist();
    _current = u;
    await _sp.setInt(_currentKey, u.id);
    notifyListeners();
    return null;
  }

  Future<String?> login(String email, String password) async {
    final u = _users.where((u) => u.email == email && u.password == password).firstOrNull;
    if (u == null) return 'Identifiants invalides';
    _current = u;
    await _sp.setInt(_currentKey, u.id);
    notifyListeners();
    return null;
  }

  Future<void> logout() async {
    _current = null;
    await _sp.remove(_currentKey);
    notifyListeners();
  }

  Future<void> _persist() async {
    await _sp.setString(_usersKey, jsonEncode(_users.map((e) => e.toJson()).toList()));
  }
}

extension FirstOrNull<E> on Iterable<E> {
  E? get firstOrNull => isEmpty ? null : first;
}
