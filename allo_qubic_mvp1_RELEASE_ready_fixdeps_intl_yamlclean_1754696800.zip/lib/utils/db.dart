import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

class AppDb {
  static Database? _db;
  static Future<Database> get db async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'allo_qubic.db');
    _db = await openDatabase(path, version: 1, onCreate: _onCreate);
    return _db!;
  }

  static Future _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE listings(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        owner_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT,
        price REAL NOT NULL,
        city TEXT,
        category TEXT,
        created_at TEXT NOT NULL
      );
    ''');
    await db.execute('''
      CREATE TABLE threads(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        listing_id INTEGER,
        user_a INTEGER NOT NULL,
        user_b INTEGER NOT NULL,
        created_at TEXT NOT NULL
      );
    ''');
    await db.execute('''
      CREATE TABLE messages(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        thread_id INTEGER NOT NULL,
        sender_id INTEGER NOT NULL,
        body TEXT NOT NULL,
        created_at TEXT NOT NULL
      );
    ''');
  }
}
