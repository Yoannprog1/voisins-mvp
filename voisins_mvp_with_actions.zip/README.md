# Voisins — Flutter Starter (MVP)
Un squelette **Android** (Flutter) pour un marketplace local de services (type AlloVoisins). **Données locales (JSON)**, pas d'API serveur (à brancher plus tard).

## Fonctionnalités incluses
- Découverte d'annonces à proximité (filtre ville/catégorie/texte)
- Création d'annonces et de demandes
- Messagerie locale (factice pour MVP)
- Profils (basiques) et notes (visuelles)
- Architecture prête pour remplacer le faux dépôt par une vraie API

## Installer / Lancer
1. **Flutter 3.22+** installé.
2. Crée un projet Flutter vide puis remplace-le par ce starter, ou clone ce dossier.
3. À la racine (là où se trouve `pubspec.yaml`) :
   ```bash
   flutter pub get
   flutter run -d android
   ```

## À prévoir pour la prod
- Auth sécurisée (Firebase Auth / Supabase)
- Stockage images (Firebase Storage / S3)
- API (Supabase/PostgREST, Node NestJS, etc.)
- Paiements (Stripe Connect), factures
- Notifications (FCM), modération, CGU/mentions légales

> **Note légale :** Projet non affilié à AlloVoisins. Respectez la marque et les CGU ; adaptez le nom/branding.
