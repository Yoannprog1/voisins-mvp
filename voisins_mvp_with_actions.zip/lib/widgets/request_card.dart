import 'package:flutter/material.dart';
import '../core/models/request.dart';

class RequestCard extends StatelessWidget {
  final ServiceRequest request;
  final VoidCallback? onTap;
  const RequestCard({super.key, required this.request, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        title: Text(request.title),
        subtitle: Text('${request.city} • ${request.category}'),
        trailing: Text('${request.budget.toStringAsFixed(0)} €'),
        onTap: onTap,
      ),
    );
  }
}
