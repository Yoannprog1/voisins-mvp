import 'package:flutter/material.dart';

class RatingStars extends StatelessWidget {
  final double rating;
  final int reviews;
  const RatingStars({super.key, required this.rating, required this.reviews});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Icon(Icons.star, size: 16),
        const SizedBox(width: 4),
        Text(rating.toStringAsFixed(1)),
        const SizedBox(width: 6),
        Text('($reviews)', style: const TextStyle(color: Colors.grey)),
      ],
    );
  }
}
