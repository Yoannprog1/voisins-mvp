import 'package:flutter/material.dart';
import '../core/models/listing.dart';
import 'rating_stars.dart';

class ListingCard extends StatelessWidget {
  final Listing listing;
  final VoidCallback? onTap;
  const ListingCard({super.key, required this.listing, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Container(
                width: 72, height: 72,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: Colors.grey.shade200,
                ),
                child: const Icon(Icons.handyman, size: 32),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(listing.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Text(listing.city, style: const TextStyle(color: Colors.grey)),
                    const SizedBox(height: 6),
                    RatingStars(rating: listing.rating, reviews: listing.reviews),
                  ],
                ),
              ),
              Text('${listing.price.toStringAsFixed(0)} €/${listing.unit}'),
            ],
          ),
        ),
      ),
    );
  }
}
