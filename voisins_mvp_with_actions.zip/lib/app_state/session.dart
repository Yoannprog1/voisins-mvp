import 'package:flutter/foundation.dart';
import '../core/models/user.dart';

class Session with ChangeNotifier {
  UserModel? _me;
  UserModel? get me => _me;

  void setMe(UserModel u) {
    _me = u;
    notifyListeners();
  }
}
