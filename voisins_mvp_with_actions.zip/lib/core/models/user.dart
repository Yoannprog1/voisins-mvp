class UserModel {
  final String id;
  final String name;
  final String city;
  final double rating;
  final int reviews;
  final String? avatar;
  final String? bio;

  const UserModel({
    required this.id,
    required this.name,
    required this.city,
    required this.rating,
    required this.reviews,
    this.avatar,
    this.bio,
  });

  factory UserModel.fromJson(Map<String, dynamic> j) => UserModel(
    id: j['id'],
    name: j['name'],
    city: j['city'] ?? '',
    rating: (j['rating'] ?? 0).toDouble(),
    reviews: (j['reviews'] ?? 0).toInt(),
    avatar: j['avatar'],
    bio: j['bio'],
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'city': city,
    'rating': rating,
    'reviews': reviews,
    'avatar': avatar,
    'bio': bio,
  };
}
