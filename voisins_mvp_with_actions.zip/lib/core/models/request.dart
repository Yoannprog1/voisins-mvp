class ServiceRequest {
  final String id;
  final String authorId;
  final String title;
  final String description;
  final double budget;
  final String city;
  final String category;
  final String status; // open, negotiating, closed

  const ServiceRequest({
    required this.id,
    required this.authorId,
    required this.title,
    required this.description,
    required this.budget,
    required this.city,
    required this.category,
    required this.status,
  });

  factory ServiceRequest.fromJson(Map<String, dynamic> j) => ServiceRequest(
    id: j['id'],
    authorId: j['authorId'],
    title: j['title'],
    description: j['description'] ?? '',
    budget: (j['budget'] ?? 0).toDouble(),
    city: j['city'] ?? '',
    category: j['category'] ?? 'Autre',
    status: j['status'] ?? 'open',
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'authorId': authorId,
    'title': title,
    'description': description,
    'budget': budget,
    'city': city,
    'category': category,
    'status': status,
  };
}
