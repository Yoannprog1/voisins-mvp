class Listing {
  final String id;
  final String ownerId;
  final String title;
  final String description;
  final double price;
  final String unit; // h, prestation, jour
  final String city;
  final String category;
  final List<String> photos;
  final double rating;
  final int reviews;

  const Listing({
    required this.id,
    required this.ownerId,
    required this.title,
    required this.description,
    required this.price,
    required this.unit,
    required this.city,
    required this.category,
    required this.photos,
    required this.rating,
    required this.reviews,
  });

  factory Listing.fromJson(Map<String, dynamic> j) => Listing(
    id: j['id'],
    ownerId: j['ownerId'],
    title: j['title'],
    description: j['description'] ?? '',
    price: (j['price'] ?? 0).toDouble(),
    unit: j['unit'] ?? 'prestation',
    city: j['city'] ?? '',
    category: j['category'] ?? 'Autre',
    photos: (j['photos'] as List?)?.cast<String>() ?? const [],
    rating: (j['rating'] ?? 0).toDouble(),
    reviews: (j['reviews'] ?? 0).toInt(),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'ownerId': ownerId,
    'title': title,
    'description': description,
    'price': price,
    'unit': unit,
    'city': city,
    'category': category,
    'photos': photos,
    'rating': rating,
    'reviews': reviews,
  };
}
