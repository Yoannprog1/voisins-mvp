class Message {
  final String from;
  final String text;
  final int ts; // epoch seconds

  const Message({required this.from, required this.text, required this.ts});

  factory Message.fromJson(Map<String, dynamic> j) =>
      Message(from: j['from'], text: j['text'], ts: (j['ts'] ?? 0).toInt());

  Map<String, dynamic> toJson() => {'from': from, 'text': text, 'ts': ts};
}

class Conversation {
  final String id;
  final String aId;
  final String bId;
  final List<Message> messages;

  Conversation({required this.id, required this.aId, required this.bId, required this.messages});

  factory Conversation.fromJson(Map<String, dynamic> j) => Conversation(
    id: j['id'],
    aId: j['aId'],
    bId: j['bId'],
    messages: (j['messages'] as List?)?.map((e) => Message.fromJson(e)).toList() ?? const [],
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'aId': aId,
    'bId': bId,
    'messages': messages.map((e) => e.toJson()).toList(),
  };
}
