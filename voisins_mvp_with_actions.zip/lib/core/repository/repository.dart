import '../models/user.dart';
import '../models/listing.dart';
import '../models/request.dart';
import '../models/message.dart';

abstract class Repository {
  Future<void> init();
  Future<UserModel?> getMe();
  Future<List<UserModel>> listUsers();
  Future<List<String>> listCategories();

  // Listings
  Future<List<Listing>> listListings({String? query, String? category, String? city});
  Future<Listing?> getListing(String id);
  Future<Listing> createListing(Listing listing);

  // Requests
  Future<List<ServiceRequest>> listRequests({String? category, String? city, String? authorId});
  Future<ServiceRequest> createRequest(ServiceRequest request);

  // Conversations
  Future<List<Conversation>> listConversations(String userId);
  Future<Conversation> sendMessage({required String convoId, required String from, required String text});
}
