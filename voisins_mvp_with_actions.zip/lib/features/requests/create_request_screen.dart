import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/repository/fake_repository.dart';
import '../../core/models/request.dart';
import '../../app_state/session.dart';

class CreateRequestScreen extends StatefulWidget {
  const CreateRequestScreen({super.key});

  @override
  State<CreateRequestScreen> createState() => _CreateRequestScreenState();
}

class _CreateRequestScreenState extends State<CreateRequestScreen> {
  final _form = GlobalKey<FormState>();
  final _title = TextEditingController();
  final _desc = TextEditingController();
  final _budget = TextEditingController();
  final _city = TextEditingController();
  String _category = 'Bricolage';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Nouvelle demande')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _form,
          child: ListView(
            children: [
              TextFormField(controller: _title, decoration: const InputDecoration(labelText: 'Titre'), validator: (v)=> v==null||v.isEmpty?'Obligatoire':null),
              TextFormField(controller: _desc, decoration: const InputDecoration(labelText: 'Description')),
              TextFormField(controller: _budget, decoration: const InputDecoration(labelText: 'Budget'), keyboardType: TextInputType.numberWithOptions(decimal: true)),
              TextFormField(controller: _city, decoration: const InputDecoration(labelText: 'Ville')),
              const SizedBox(height: 8),
              DropdownButtonFormField(value: _category, items: const [
                DropdownMenuItem(value: 'Bricolage', child: Text('Bricolage')),
                DropdownMenuItem(value: 'Jardinage', child: Text('Jardinage')),
                DropdownMenuItem(value: 'Déménagement', child: Text('Déménagement')),
                DropdownMenuItem(value: 'Informatique', child: Text('Informatique')),
                DropdownMenuItem(value: 'Ménage', child: Text('Ménage')),
              ], onChanged: (v)=> setState(()=> _category = v ?? 'Bricolage'), decoration: const InputDecoration(labelText: 'Catégorie')),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: () async {
                  if(!_form.currentState!.validate()) return;
                  final me = context.read<Session>().me!;
                  final repo = FakeRepository();
                  await repo.init();
                  await repo.createRequest(ServiceRequest(
                    id: 'tmp', authorId: me.id, title: _title.text, description: _desc.text,
                    budget: double.tryParse(_budget.text) ?? 0, city: _city.text,
                    category: _category, status: 'open',
                  ));
                  if(mounted) Navigator.pop(context);
                },
                child: const Text('Poster'),
              )
            ],
          ),
        ),
      ),
    );
  }
}
