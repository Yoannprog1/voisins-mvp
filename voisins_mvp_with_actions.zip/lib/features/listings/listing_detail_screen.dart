import 'package:flutter/material.dart';
import '../../core/models/listing.dart';
import '../../core/repository/fake_repository.dart';

class ListingDetailScreen extends StatefulWidget {
  final String listingId;
  const ListingDetailScreen({super.key, required this.listingId});

  @override
  State<ListingDetailScreen> createState() => _ListingDetailScreenState();
}

class _ListingDetailScreenState extends State<ListingDetailScreen> {
  Listing? listing;

  @override
  void initState() {
    super.initState();
    final repo = FakeRepository();
    repo.init().then((_) async {
      listing = await repo.getListing(widget.listingId);
      if (mounted) setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    final l = listing;
    if (l == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: Text(l.title)),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${l.price.toStringAsFixed(0)} €/${l.unit}', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.place_outlined),
                const SizedBox(width: 4),
                Text(l.city),
                const SizedBox(width: 12),
                Chip(label: Text(l.category)),
              ],
            ),
            const SizedBox(height: 12),
            Text(l.description),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => Navigator.pushNamed(context, '/chat'),
                icon: const Icon(Icons.chat),
                label: const Text('Contacter'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
