import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/repository/repository.dart';
import '../../core/repository/fake_repository.dart';
import '../../core/models/user.dart';
import '../../widgets/listing_card.dart';
import '../../widgets/request_card.dart';
import '../../core/models/listing.dart';
import '../../core/models/request.dart';
import '../../app_state/session.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late final Repository repo;
  int _tab = 0;
  List<Listing> _listings = [];
  List<ServiceRequest> _requests = [];
  List<String> _categories = [];
  String _city = '';
  String _category = '';
  String _query = '';

  @override
  void initState() {
    super.initState();
    repo = FakeRepository();
    repo.init().then((_) async {
      final me = await repo.getMe();
      if (me != null && mounted) context.read<Session>().setMe(me);
      _categories = await repo.listCategories();
      await _refresh();
    });
  }

  Future<void> _refresh() async {
    _listings = await repo.listListings(query: _query, category: _category, city: _city.isEmpty ? null : _city);
    _requests = await repo.listRequests(category: _category, city: _city.isEmpty ? null : _city);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final me = context.watch<Session>().me;
    return Scaffold(
      appBar: AppBar(title: const Text('Voisins')),
      body: Column(
        children: [
          _Filters(
            categories: _categories,
            onApply: (q, c, city) { _query = q; _category = c; _city = city; _refresh(); },
          ),
          Expanded(
            child: RefreshIndicator(
              onRefresh: _refresh,
              child: _tab == 0 ? _buildDiscover() : _tab == 1 ? _buildRequests() : _tab == 2 ? _buildInbox(me) : _buildProfile(),
            ),
          ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.explore_outlined), label: 'Découvrir'),
          NavigationDestination(icon: Icon(Icons.assignment_outlined), label: 'Demandes'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'Messages'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profil'),
        ],
      ),
      floatingActionButton: _tab <= 1 ? FloatingActionButton.extended(
        onPressed: () => Navigator.pushNamed(context, _tab == 0 ? '/listing/create' : '/request/create').then((_) => _refresh()),
        icon: const Icon(Icons.add),
        label: Text(_tab == 0 ? 'Ajouter une annonce' : 'Poster une demande'),
      ) : null,
    );
  }

  Widget _buildDiscover() {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: _listings.length,
      itemBuilder: (_, i) => ListingCard(
        listing: _listings[i],
        onTap: () => Navigator.pushNamed(context, '/listing/detail', arguments: _listings[i].id),
      ),
    );
  }

  Widget _buildRequests() {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: _requests.length,
      itemBuilder: (_, i) => RequestCard(request: _requests[i]),
    );
  }

  Widget _buildInbox(UserModel? me) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.chat_bubble_outline, size: 64, color: Colors.grey),
          const SizedBox(height: 8),
          const Text('Messagerie locale (MVP)', style: TextStyle(color: Colors.grey)),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: () => Navigator.pushNamed(context, '/chat'),
            icon: const Icon(Icons.chat),
            label: const Text('Ouvrir une conversation démo'),
          )
        ],
      ),
    );
  }

  Widget _buildProfile() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.person_outline, size: 64, color: Colors.grey),
          const SizedBox(height: 8),
          const Text('Profil (MVP)', style: TextStyle(color: Colors.grey)),
          const SizedBox(height: 12),
          ElevatedButton(
            onPressed: () => Navigator.pushNamed(context, '/profile/edit'),
            child: const Text('Éditer le profil'),
          )
        ],
      ),
    );
  }
}

class _Filters extends StatefulWidget {
  final List<String> categories;
  final void Function(String query, String category, String city) onApply;
  const _Filters({required this.categories, required this.onApply});

  @override
  State<_Filters> createState() => _FiltersState();
}

class _FiltersState extends State<_Filters> {
  String query = '';
  String category = '';
  String city = '';

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.grey.shade300))),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: TextField(
                  decoration: const InputDecoration(hintText: 'Rechercher un service (ex: tonte)', prefixIcon: Icon(Icons.search)),
                  onChanged: (v) => query = v,
                ),
              ),
              const SizedBox(width: 8),
              SizedBox(
                width: 120,
                child: TextField(
                  decoration: const InputDecoration(hintText: 'Ville', prefixIcon: Icon(Icons.place_outlined)),
                  onChanged: (v) => city = v,
                ),
              ),
              const SizedBox(width: 8),
              DropdownButton<String>(
                value: category.isEmpty ? null : category,
                hint: const Text('Catégorie'),
                items: widget.categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                onChanged: (v) => setState(() => category = v ?? ''),
              ),
              const SizedBox(width: 8),
              ElevatedButton(onPressed: () => widget.onApply(query, category, city), child: const Text('Filtrer'))
            ],
          ),
        ],
      ),
    );
  }
}
