import 'package:flutter/material.dart';
import '../../core/repository/fake_repository.dart';
import '../../core/models/message.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _ctrl = TextEditingController();
  Conversation? _convo;

  @override
  void initState() {
    super.initState();
    final repo = FakeRepository();
    repo.init().then((_) async {
      final convos = await repo.listConversations('u_me');
      _convo = convos.isNotEmpty ? convos.first : null;
      if (mounted) setState(() {});
    });
  }

  Future<void> _send() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty || _convo == null) return;
    _ctrl.clear();
    final repo = FakeRepository();
    await repo.init();
    _convo = await repo.sendMessage(convoId: _convo!.id, from: 'u_me', text: text);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final c = _convo;
    return Scaffold(
      appBar: AppBar(title: const Text('Conversation')),
      body: c == null
          ? const Center(child: Text('Aucune conversation'))
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: c.messages.length,
                    itemBuilder: (_, i) {
                      final m = c.messages[i];
                      final fromMe = m.from == 'u_me';
                      return Align(
                        alignment: fromMe ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          decoration: BoxDecoration(
                            color: fromMe ? Colors.blue.shade100 : Colors.grey.shade200,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(m.text),
                        ),
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      Expanded(child: TextField(controller: _ctrl, decoration: const InputDecoration(hintText: 'Votre message'))),
                      IconButton(onPressed: _send, icon: const Icon(Icons.send))
                    ],
                  ),
                )
              ],
            ),
    );
  }
}
