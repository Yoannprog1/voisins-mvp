import 'package:flutter/material.dart';
import '../features/home/home_screen.dart';
import '../features/listings/create_listing_screen.dart';
import '../features/listings/listing_detail_screen.dart';
import '../features/requests/create_request_screen.dart';
import '../features/chat/chat_screen.dart';
import '../features/profile/edit_profile_screen.dart';

class AppRouter {
  static Map<String, WidgetBuilder> routes = {
    '/': (_) => const HomeScreen(),
    '/listing/create': (_) => const CreateListingScreen(),
    '/request/create': (_) => const CreateRequestScreen(),
    '/chat': (_) => const ChatScreen(),
    '/profile/edit': (_) => const EditProfileScreen(),
  };

  static Route<dynamic> onGenerateRoute(RouteSettings s) {
    switch (s.name) {
      case '/listing/detail':
        final id = s.arguments as String;
        return MaterialPageRoute(builder: (_) => ListingDetailScreen(listingId: id));
      default:
        return MaterialPageRoute(builder: (_) => const HomeScreen());
    }
  }
}
