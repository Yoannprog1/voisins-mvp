import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

class QubicPaymentScreen extends StatefulWidget {
  const QubicPaymentScreen({super.key});

  @override
  State<QubicPaymentScreen> createState() => _QubicPaymentScreenState();
}

class _QubicPaymentScreenState extends State<QubicPaymentScreen> {
  final _addrCtrl = TextEditingController();
  final _amountCtrl = TextEditingController(text: '1.0');
  final _memoCtrl = TextEditingController(text: 'Booking');

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final sp = await SharedPreferences.getInstance();
    _addrCtrl.text = sp.getString('qubic_addr') ?? '';
  }

  Future<void> _saveAddr() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString('qubic_addr', _addrCtrl.text.trim());
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Adresse enregistrée')));
  }

  Uri _buildUri() {
    final to = _addrCtrl.text.trim();
    final amount = _amountCtrl.text.trim();
    final memo = _memoCtrl.text.trim();
    // Schéma hypothétique "qubic://pay" — selon ton wallet, à ajuster.
    return Uri.parse('qubic://pay?to=$to&amount=$amount&memo=$memo');
  }

  @override
  Widget build(BuildContext context) {
    final uri = _buildUri();
    return Scaffold(
      appBar: AppBar(title: const Text('Paiement QUBIC (démo)')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            const Text('Adresse QUBIC du marchand'),
            TextField(controller: _addrCtrl, decoration: const InputDecoration(hintText: 'QUBIC_WALLET_ADDRESS')),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: TextField(controller: _amountCtrl, decoration: const InputDecoration(labelText: 'Montant QUBIC'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: _memoCtrl, decoration: const InputDecoration(labelText: 'Mémo'))),
              ],
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: _saveAddr,
              icon: const Icon(Icons.save),
              label: const Text('Enregistrer l’adresse'),
            ),
            const SizedBox(height: 12),
            ListTile(
              title: const Text('Lien deeplink'),
              subtitle: Text(uri.toString()),
              trailing: IconButton(
                icon: const Icon(Icons.open_in_new),
                onPressed: () async {
                  final u = uri.toString();
                  if (await canLaunchUrl(Uri.parse(u))) {
                    await launchUrl(Uri.parse(u));
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Aucun wallet QUBIC détecté pour ce lien.')));
                  }
                },
              ),
            ),
            const SizedBox(height: 8),
            const Text('Note : ce deeplink dépend du wallet installé. Si le schéma n’est pas supporté, copie l’adresse et paie manuellement.'),
          ],
        ),
      ),
    );
  }
}
