import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';
import '../auth/auth_service.dart';
import '../listings/listing.dart';
import '../listings/listings_repo.dart';
import '../listings/listing_detail_screen.dart';
import '../listings/create_edit_listing_screen.dart';
import '../ui/gradient_scaffold.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _search = TextEditingController();
  final _repo = ListingsRepo();
  bool _busy = false;
  List<Listing> _items = [];

  final categories = const [
    ('🔧', 'Bricolage'),
    ('🧹', 'Ménage'),
    ('📦', 'Déménagement'),
    ('🐶', 'Petsitting'),
    ('📚', 'Cours'),
    ('🌿', 'Jardin'),
  ];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _busy = true);
    await Future.delayed(const Duration(milliseconds: 400));
    _items = await _repo.all(q: _search.text.trim());
    setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthService>().currentUser;
    return GradientScaffold(
      appBar: AppBar(
        title: Text('Bonjour ${user?.name ?? ''}'.trim()),
        actions: [
          IconButton(icon: const Icon(Icons.tune), onPressed: _openFilters),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
          children: [
            _SearchBar(controller: _search, onSubmitted: (_) => _load()),
            const SizedBox(height: 12),
            _CategoriesRow(items: categories),
            const SizedBox(height: 16),
            Row(
              children: const [
                Text('Près de chez vous', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                Spacer(),
                Icon(Icons.chevron_right),
              ],
            ),
            const SizedBox(height: 8),
            if (_busy) ...List.generate(6, (_) => const _ListingSkeleton()),
            if (!_busy && _items.isEmpty) _EmptyState(onRetry: _load),
            if (!_busy && _items.isNotEmpty)
              ..._items.map((it) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: _ListingCard(
                  item: it,
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(
                      builder: (_) => ListingDetailScreen(listing: it),
                    ));
                  },
                ),
              )),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(context,
          MaterialPageRoute(builder: (_) => const CreateEditListingScreen()))
          .then((_) => _load()),
        icon: const Icon(Icons.add),
        label: const Text('Publier'),
      ),
    );
  }

  void _openFilters() {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (_) => const _FiltersSheet(),
    );
  }
}

class _SearchBar extends StatelessWidget {
  final TextEditingController controller;
  final ValueChanged<String> onSubmitted;
  const _SearchBar({required this.controller, required this.onSubmitted});

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      onSubmitted: onSubmitted,
      textInputAction: TextInputAction.search,
      decoration: const InputDecoration(
        hintText: 'Rechercher un service (ex: Bricolage)…',
        prefixIcon: Icon(Icons.search),
      ),
    );
  }
}

class _CategoriesRow extends StatelessWidget {
  final List<(String, String)> items;
  const _CategoriesRow({required this.items});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 88,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (_, i) {
          final (emoji, label) = items[i];
          return Container(
            width: 120,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: const LinearGradient(
                colors: [Color(0xFFDBEAFE), Colors.white],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 8, offset: Offset(0,3))],
            ),
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(emoji, style: const TextStyle(fontSize: 22)),
                const Spacer(),
                Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _ListingCard extends StatelessWidget {
  final Listing item;
  final VoidCallback onTap;
  const _ListingCard({required this.item, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Row(
          children: [
            Container(
              width: 96, height: 96,
              color: const Color(0xFFF1F5F9),
              child: const Icon(Icons.handyman, size: 36, color: Colors.black54),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 4),
                    Text(item.description, maxLines: 2, overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Icon(Icons.star, size: 16, color: Color(0xFFF59E0B)),
                        const SizedBox(width: 4),
                        const Text('4.9'),
                        const SizedBox(width: 12),
                        const Icon(Icons.place, size: 16),
                        const SizedBox(width: 4),
                        Text(item.city),
                        const Spacer(),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: const Color(0xFFEFF6FF),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text('€${item.price.toStringAsFixed(0)}/h'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ListingSkeleton extends StatelessWidget {
  const _ListingSkeleton();
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Shimmer.fromColors(
        baseColor: const Color(0xFFE5E7EB),
        highlightColor: const Color(0xFFF3F4F6),
        child: Container(height: 96, decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(16),
        )),
      ),
    );
  }
}

class _FiltersSheet extends StatefulWidget {
  const _FiltersSheet();
  @override
  State<_FiltersSheet> createState() => _FiltersSheetState();
}

class _FiltersSheetState extends State<_FiltersSheet> {
  String tri = 'Pertinence';
  double rayon = 10;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Filtres', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          const Text('Tri'),
          DropdownButton<String>(
            value: tri,
            items: const [
              DropdownMenuItem(value: 'Pertinence', child: Text('Pertinence')),
              DropdownMenuItem(value: 'Plus proche', child: Text('Plus proche')),
              DropdownMenuItem(value: 'Moins cher', child: Text('Moins cher')),
              DropdownMenuItem(value: 'Mieux noté', child: Text('Mieux noté')),
              DropdownMenuItem(value: 'Nouveautés', child: Text('Nouveautés')),
            ],
            onChanged: (v) => setState(() => tri = v ?? tri),
          ),
          const SizedBox(height: 8),
          Text('Rayon : ${rayon.toStringAsFixed(0)} km'),
          Slider(min: 1, max: 50, divisions: 49, value: rayon, onChanged: (v) => setState(() => rayon = v)),
          const SizedBox(height: 8),
          FilledButton.icon(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.check), label: const Text('Appliquer')),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final VoidCallback onRetry;
  const _EmptyState({required this.onRetry});
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 220,
      alignment: Alignment.center,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.search_off, size: 56, color: Colors.black45),
          const SizedBox(height: 8),
          const Text('Aucune annonce trouvée'),
          const SizedBox(height: 4),
          OutlinedButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh), label: const Text('Réessayer')),
        ],
      ),
    );
  }
}
