import 'package:sqflite/sqflite.dart';
import '../utils/db.dart';
import 'listing.dart';

class ListingsRepo {
  Future<int> create(Listing l) async {
    final db = await AppDb.db;
    return db.insert('listings', l.toMap());
  }

  Future<List<Listing>> all({String q = ''}) async {
    final db = await AppDb.db;
    final rows = await db.query(
      'listings',
      where: q.isNotEmpty ? 'title LIKE ? OR description LIKE ?' : null,
      whereArgs: q.isNotEmpty ? ['%$q%', '%$q%'] : null,
      orderBy: 'created_at DESC'
    );
    return rows.map((e) => Listing.fromMap(e)).toList();
  }

  Future<void> delete(int id) async {
    final db = await AppDb.db;
    await db.delete('listings', where: 'id = ?', whereArgs: [id]);
  }
}
