import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../auth/auth_service.dart';
import '../chat/chat_service.dart';
import '../chat/thread_screen.dart';
import 'listing.dart';

class ListingDetailScreen extends StatelessWidget {
  final Listing listing;
  const ListingDetailScreen({super.key, required this.listing});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    final isOwner = auth.currentUser?.id == listing.ownerId;
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: Text(listing.title)),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('${listing.price.toStringAsFixed(2)} €', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text('${listing.city} • ${listing.category}'),
              const SizedBox(height: 12),
              Text(listing.description),
              const Spacer(),
              if (!isOwner)
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: () async {
                          final threadId = await ChatService().ensureThread(listingId: listing.id, a: auth.currentUser!.id, b: listing.ownerId);
                          if (context.mounted) {
                            Navigator.push(context, MaterialPageRoute(builder: (_) => ThreadScreen(threadId: threadId)));
                          }
                        },
                        icon: const Icon(Icons.chat_bubble_outline),
                        label: const Text('Contacter'),
                      ),
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}
