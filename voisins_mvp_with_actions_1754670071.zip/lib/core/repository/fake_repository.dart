import 'dart:convert'; import 'package:flutter/services.dart' show rootBundle; import 'package:uuid/uuid.dart';
import '../models/user.dart'; import '../models/listing.dart'; import '../models/request.dart'; import '../models/message.dart'; import 'repository.dart';
class FakeRepository implements Repository{
  final _uuid=const Uuid(); late Map<String,dynamic> _db;
  Future<void> init() async{ final raw=await rootBundle.loadString('assets/seed.json'); _db=json.decode(raw) as Map<String,dynamic>; }
  Future<UserModel?> getMe() async{ final users=(_db['users'] as List).map((e)=>UserModel.fromJson(e)).toList(); return users.firstWhere((u)=>u.id=='u_me'); }
  Future<List<UserModel>> listUsers() async=>(_db['users'] as List).map((e)=>UserModel.fromJson(e)).toList();
  Future<List<String>> listCategories() async=>(_db['categories'] as List).cast<String>();
  Future<List<Listing>> listListings({String? query,String? category,String? city}) async{
    var list=(_db['listings'] as List).map((e)=>Listing.fromJson(e)).toList();
    if(category!=null&&category.isNotEmpty) list=list.where((l)=>l.category==category).toList();
    if(city!=null&&city.isNotEmpty) list=list.where((l)=>l.city.toLowerCase()==city.toLowerCase()).toList();
    if(query!=null&&query.isNotEmpty){final q=query.toLowerCase(); list=list.where((l)=>l.title.toLowerCase().contains(q)||l.description.toLowerCase().contains(q)).toList();}
    return list; }
  Future<Listing?> getListing(String id) async{ final list=await listListings(); try{return list.firstWhere((l)=>l.id==id);}catch(_){return null;} }
  Future<Listing> createListing(Listing l0) async{ final nl=Listing(id:_uuid.v4(),ownerId:l0.ownerId,title:l0.title,description:l0.description,price:l0.price,unit:l0.unit,city:l0.city,category:l0.category,photos:l0.photos,rating:0,reviews:0);
    final list=(_db['listings'] as List); list.add(nl.toJson()); return nl; }
  Future<List<ServiceRequest>> listRequests({String? category,String? city,String? authorId}) async{
    var list=(_db['requests'] as List).map((e)=>ServiceRequest.fromJson(e)).toList();
    if(category!=null&&category.isNotEmpty) list=list.where((r)=>r.category==category).toList();
    if(city!=null&&city.isNotEmpty) list=list.where((r)=>r.city.toLowerCase()==city.toLowerCase()).toList();
    if(authorId!=null&&authorId.isNotEmpty) list=list.where((r)=>r.authorId==authorId).toList();
    return list; }
  Future<ServiceRequest> createRequest(ServiceRequest r0) async{ final r=ServiceRequest(id:_uuid.v4(),authorId:r0.authorId,title:r0.title,description:r0.description,budget:r0.budget,city:r0.city,category:r0.category,status:'open');
    final list=(_db['requests'] as List); list.add(r.toJson()); return r; }
  Future<List<Conversation>> listConversations(String userId) async{
    final cs=(_db['conversations'] as List).map((e)=>Conversation.fromJson(e)).where((c)=>c.aId==userId||c.bId==userId).toList(); return cs; }
  Future<Conversation> sendMessage({required String convoId,required String from,required String text}) async{
    final convos=(_db['conversations'] as List); final idx=convos.indexWhere((e)=>e['id']==convoId);
    if(idx>=0){ final messages=(convos[idx]['messages'] as List); messages.add({'from':from,'text':text,'ts':DateTime.now().millisecondsSinceEpoch~/1000}); return Conversation.fromJson(convos[idx]); }
    final c={'id':const Uuid().v4(),'aId':from,'bId':'u1','messages':[{'from':from,'text':text,'ts':DateTime.now().millisecondsSinceEpoch~/1000}]}; convos.add(c); return Conversation.fromJson(c);
  } }
