import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

typedef CitySelected = void Function(String city, double lat, double lng);

class CityField extends StatefulWidget {
  final CitySelected onSelected;
  final String? initialCity;
  const CityField({super.key, required this.onSelected, this.initialCity});

  @override
  State<CityField> createState() => _CityFieldState();
}

class _CityFieldState extends State<CityField> {
  late final TextEditingController _ctrl;
  Timer? _debounce;
  List<_CitySuggestion> _suggestions = [];

  @override
  void initState() {
    super.initState();
    _ctrl = TextEditingController(text: widget.initialCity ?? '');
    _ctrl.addListener(_onChanged);
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _ctrl.dispose();
    super.dispose();
  }

  void _onChanged() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 250), () async {
      final q = _ctrl.text.trim();
      if (q.isEmpty) {
        setState(() => _suggestions = []);
        return;
      }
      try {
        final uri = Uri.https('api-adresse.data.gouv.fr', '/search/', {
          'q': q,
          'type': 'municipality',
          'limit': '6',
        });
        final res = await http.get(uri);
        if (res.statusCode == 200) {
          final json = jsonDecode(res.body) as Map<String, dynamic>;
          final feats = (json['features'] as List? ?? []);
          final out = <_CitySuggestion>[];
          for (final f in feats) {
            final props = f['properties'] as Map<String, dynamic>? ?? {};
            final geom = f['geometry'] as Map<String, dynamic>? ?? {};
            final coords = (geom['coordinates'] as List?) ?? [];
            if (coords.length >= 2) {
              final lon = (coords[0] as num).toDouble();
              final lat = (coords[1] as num).toDouble();
              final label = (props['label'] ?? props['name'] ?? '').toString();
              if (label.isNotEmpty) {
                out.add(_CitySuggestion(label: label, lat: lat, lng: lon));
              }
            }
          }
          if (mounted) setState(() => _suggestions = out);
        } else {
          if (mounted) setState(() => _suggestions = []);
        }
      } catch (_) {
        if (mounted) setState(() => _suggestions = []);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextFormField(
          controller: _ctrl,
          decoration: const InputDecoration(
            labelText: 'Ville',
            hintText: 'Paris, Lyon, Bordeaux…',
            border: OutlineInputBorder(),
          ),
        ),
        if (_suggestions.isNotEmpty) ...[
          const SizedBox(height: 6),
          Container(
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Theme.of(context).dividerColor),
            ),
            child: ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              padding: const EdgeInsets.symmetric(vertical: 6),
              itemCount: _suggestions.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, i) {
                final s = _suggestions[i];
                return ListTile(
                  dense: true,
                  leading: const Icon(Icons.location_city),
                  title: Text(s.label),
                  onTap: () {
                    widget.onSelected(s.label, s.lat, s.lng);
                    setState(() {
                      _ctrl.text = s.label;
                      _suggestions = [];
                    });
                  },
                );
              },
            ),
          ),
        ],
      ],
    );
  }
}

class _CitySuggestion {
  final String label;
  final double lat;
  final double lng;
  _CitySuggestion({required this.label, required this.lat, required this.lng});
}
