BAN (api-adresse.data.gouv.fr) — Ville gratuite, sans clé
========================================================

Ce patch remplace le champ Ville pour utiliser l'API publique française :
https://api-adresse.data.gouv.fr (Base Adresse Nationale). Aucune clé requise.

Inclus :
- lib/features/publish/city_field.dart (nouvelle version, gratuite)
- .github/workflows/build_from_zip.yml (supprime google_place, ajoute http)

Étapes :
1) Uploadez ce ZIP à la racine du repo, commit sur main.
2) Dans Actions, vérifiez le build et téléchargez l'APK 'app-debug'.

Si vous utilisez mon entrypoint HomeFeed (main_homefeed.dart), adaptez la commande de build :
  flutter build apk -t lib/main_homefeed.dart --debug --dart-define=SUPABASE_URL=${{ secrets.SUPABASE_URL }} --dart-define=SUPABASE_ANON=${{ secrets.SUPABASE_ANON }}

Notes :
- Lat/Lng fournis par BAN → filtres par distance OK.
- Pas de compte ni de carte bancaire.
