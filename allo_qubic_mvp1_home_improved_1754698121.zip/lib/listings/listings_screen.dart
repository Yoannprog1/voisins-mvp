import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../auth/auth_service.dart';
import 'listing.dart';
import 'listings_repo.dart';
import '../chat/chat_service.dart';
import '../chat/thread_screen.dart';
import 'create_edit_listing_screen.dart';
import 'listing_detail_screen.dart';

class ListingsScreen extends StatefulWidget {
  const ListingsScreen({super.key});
  @override
  State<ListingsScreen> createState() => _ListingsScreenState();
}

class _ListingsScreenState extends State<ListingsScreen> {
  final _repo = ListingsRepo();
  List<Listing> _items = [];
  String _query = '';
  bool _busy = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _busy = true);
    _items = await _repo.all(q: _query);
    setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Annonces'),
          actions: [
            IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
          ],
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(56),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                decoration: const InputDecoration(
                  hintText: 'Rechercher...',
                  prefixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
                onChanged: (v) { _query = v; },
                onSubmitted: (v) { _query = v; _load(); },
              ),
            ),
          ),
        ),
        body: _busy
            ? const Center(child: CircularProgressIndicator())
            : _items.isEmpty
                ? const Center(child: Text('Aucune annonce pour le moment.'))
                : ListView.separated(
                    itemBuilder: (_, i) {
                      final l = _items[i];
                      return ListTile(
                        title: Text(l.title),
                        subtitle: Text('${l.price.toStringAsFixed(2)} € • ${l.city} • ${DateFormat.yMMMd().format(l.createdAt)}'),
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ListingDetailScreen(listing: l))).then((_) => _load()),
                        trailing: PopupMenuButton(
                          itemBuilder: (_) => [
                            const PopupMenuItem(value: 'contact', child: Text('Contacter')),
                            const PopupMenuItem(value: 'delete', child: Text('Supprimer')),
                          ],
                          onSelected: (v) async {
                            if (v == 'delete') {
                              await ListingsRepo().delete(l.id);
                              _load();
                            } else if (v == 'contact') {
                              final auth = context.read<AuthService>();
                              final threadId = await ChatService().ensureThread(listingId: l.id, a: auth.currentUser!.id, b: l.ownerId);
                              // open thread
                              if (context.mounted) {
                                Navigator.push(context, MaterialPageRoute(builder: (_) => ThreadScreen(threadId: threadId)));
                              }
                            }
                          },
                        ),
                      );
                    },
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemCount: _items.length,
                  ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CreateEditListingScreen())).then((_) => _load()),
          icon: const Icon(Icons.add),
          label: const Text('Publier'),
        ),
      ),
    );
  }
}
