
PATCH UI — v3
--------------
Ce ZIP contient uniquement des fichiers **additionnels** pour améliorer l'UI.
➡ Dézippez-le **à la racine** de votre projet existant. Cela n’écrase aucun fichier critique.

FICHIERS AJOUTÉS
- lib/theme/app_theme.dart           : thème modernisé (Material 3, Google Fonts, chips, inputs, buttons).
- lib/widgets/brand_gradient.dart    : bandeau dégradé pour l'accueil.
- lib/widgets/section_title.dart     : titres de sections.
- lib/widgets/skeleton_list.dart     : skeletons sans dépendance externe.
- lib/widgets/empty_state.dart       : état vide réutilisable.
- lib/widgets/avatar_badge.dart      : avatar avec badge "nouveau" par ex.
- lib/utils/snack.dart               : helper SnackBar.
- lib/home/create_request_sheet.dart : bottom sheet "Créer une demande".
- lib/home/home_enhanced.dart        : nouvel écran d'accueil inspiré AV.

INTÉGRATION
1) Thème global :
   Dans votre `main.dart` ou fichier App, appliquez :
     import 'package:voisins_v2/theme/app_theme.dart';
     MaterialApp(theme: AppTheme.light(), ...)

2) Routes :
   Ajoutez les routes vers les nouveaux écrans si besoin :
     routes: {
       '/home2': (_) => const HomeEnhancedScreen(),
     }

3) Lancer l'accueil enrichi (optionnel) :
   Utilisez `HomeEnhancedScreen()` comme page d'accueil pour tester.

4) Bouton "Demande" :
   Le FAB ouvre `showCreateRequestSheet(context)` (catégories courantes).

5) Aucune dépendance nouvelle à ajouter. Compile en l'état avec Flutter 3.22+.

Bon build !
