
import 'package:flutter/material.dart';

Future<void> showCreateRequestSheet(BuildContext context) async {
  final categories = [
    ('Bricolage', Icons.construction_outlined),
    ('Jardinage', Icons.yard_outlined),
    ('Déménagement', Icons.local_shipping_outlined),
    ('Informatique', Icons.computer_outlined),
    ('Ménage', Icons.cleaning_services_outlined),
    ('Autre', Icons.more_horiz),
  ];

  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    builder: (_) {
      return SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('De quoi avez-vous besoin ?', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
              const SizedBox(height: 12),
              GridView.builder(
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: .9,
                ),
                itemCount: categories.length,
                itemBuilder: (_, i) {
                  final (label, icon) = categories[i];
                  return InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, '/request/new', arguments: {'category': label});
                    },
                    child: Ink(
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(icon, size: 28),
                          const SizedBox(height: 8),
                          Text(label, textAlign: TextAlign.center),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      );
    },
  );
}
