
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../auth/auth_service.dart';
import '../widgets/brand_gradient.dart';
import '../widgets/section_title.dart';
import '../widgets/skeleton_list.dart';
import '../utils/snack.dart';
import 'create_request_sheet.dart';

/// Nouvel écran d'accueil inspiré d'Allo Voisins, non destructif.
class HomeEnhancedScreen extends StatefulWidget {
  const HomeEnhancedScreen({super.key});
  @override
  State<HomeEnhancedScreen> createState() => _HomeEnhancedScreenState();
}

class _HomeEnhancedScreenState extends State<HomeEnhancedScreen> {
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 900), () {
      if (mounted) setState(() => _loading = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    final name = (auth.currentUser?.email ?? 'Voisin').split('@').first;

    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showCreateRequestSheet(context),
        icon: const Icon(Icons.add),
        label: const Text('Demande'),
      ),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: BrandGradient(
              height: 165,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.location_on_outlined, color: Colors.white70, size: 18),
                        const SizedBox(width: 6),
                        Text('Champigny', style: TextStyle(color: Colors.white.withOpacity(.9))),
                        const Spacer(),
                        IconButton(
                          onPressed: () => showSnack(context, 'Notifications'),
                          icon: const Icon(Icons.notifications_none, color: Colors.white),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text('Bonjour $name', style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 10),
                    TextField(
                      onTap: () {},
                      readOnly: true,
                      decoration: const InputDecoration(
                        hintText: 'De quoi avez-vous besoin aujourd\'hui ?',
                        prefixIcon: Icon(Icons.search),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(child: const SizedBox(height: 8)),
          SliverToBoxAdapter(child: const SectionTitle('Demande publique')),
          if (_loading)
            SliverFillRemaining(
              hasScrollBody: false,
              child: const SkeletonList(count: 4),
            )
          else
            SliverList(
              delegate: SliverChildListDelegate([
                _PublicRequestCard(
                  name: 'Nadège B.',
                  text: 'Bonjour, je souhaite faire réparer mon sèche-linge.',
                  city: 'Paron',
                  distance: 'à 17,2 km',
                  time: 'postée hier',
                ),
                _PublicRequestCard(
                  name: 'Luc M.',
                  text: 'Besoin d’aide pour poser une tringle à rideaux',
                  city: 'Champigny',
                  distance: 'à 2,1 km',
                  time: 'il y a 3 h',
                ),
              ]),
            ),
          SliverToBoxAdapter(child: const SectionTitle('Thématiques du moment')),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 160,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: const [
                  _ThemeCard(title: "Petits travaux", likes: 7137),
                  SizedBox(width: 12),
                  _ThemeCard(title: "Jardinage d'été", likes: 1462),
                ],
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 90)),
        ],
      ),
    );
  }
}

class _PublicRequestCard extends StatelessWidget {
  final String name, text, city, distance, time;
  const _PublicRequestCard({required this.name, required this.text, required this.city, required this.distance, required this.time});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: Material(
        color: cs.surface,
        elevation: 0,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: (){},
          child: Ink(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: cs.outlineVariant),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const CircleAvatar(radius: 18, child: Icon(Icons.person_outline)),
                    const SizedBox(width: 8),
                    Text(name, style: const TextStyle(fontWeight: FontWeight.w800)),
                    const Spacer(),
                    Text(time, style: TextStyle(color: cs.outline)),
                  ],
                ),
                const SizedBox(height: 10),
                Text(text),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Icon(Icons.place_outlined, size: 16, color: cs.outline),
                    const SizedBox(width: 4),
                    Text('$city · $distance', style: TextStyle(color: cs.outline)),
                    const Spacer(),
                    OutlinedButton.icon(onPressed: (){}, icon: const Icon(Icons.reply_outlined), label: const Text('Répondre')),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ThemeCard extends StatelessWidget {
  final String title; final int likes;
  const _ThemeCard({required this.title, required this.likes});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      width: 260,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: cs.surfaceContainerHighest,
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Container(color: cs.primary.withOpacity(.08)),
          Align(
            alignment: Alignment.bottomLeft,
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w800, color: Colors.black)),
                  const SizedBox(height: 6),
                  Row(children: [
                    const Icon(Icons.favorite_border, size: 16),
                    const SizedBox(width: 6),
                    Text('$likes'),
                  ]),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
