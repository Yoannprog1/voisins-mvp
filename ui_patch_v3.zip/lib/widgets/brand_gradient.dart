
import 'package:flutter/material.dart';

/// Bandeau dégradé réutilisable (header d'accueil).
class BrandGradient extends StatelessWidget {
  final Widget child;
  final double height;
  const BrandGradient({super.key, required this.child, this.height = 160});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      height: height,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            cs.primary.withOpacity(.95),
            cs.primaryContainer,
          ],
        ),
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(24),
          bottomRight: Radius.circular(24),
        ),
      ),
      child: SafeArea(child: child),
    );
  }
}
