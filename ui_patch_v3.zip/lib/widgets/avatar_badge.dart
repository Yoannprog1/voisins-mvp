
import 'package:flutter/material.dart';

class AvatarWithBadge extends StatelessWidget {
  final String initials;
  final IconData? badge;
  final Color? badgeColor;
  const AvatarWithBadge({
    super.key,
    required this.initials,
    this.badge,
    this.badgeColor,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        CircleAvatar(
          radius: 24,
          child: Text(initials, style: const TextStyle(fontWeight: FontWeight.w800)),
        ),
        if (badge != null)
          Positioned(
            right: -2, bottom: -2,
            child: Container(
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                color: badgeColor ?? Colors.orange,
                shape: BoxShape.circle,
                border: Border.all(color: Theme.of(context).colorScheme.surface, width: 2),
              ),
              child: Icon(badge, size: 14, color: Colors.white),
            ),
          ),
      ],
    );
  }
}
