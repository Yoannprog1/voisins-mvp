
import 'package:flutter/material.dart';

class SectionTitle extends StatelessWidget {
  final String text; final EdgeInsets? padding;
  const SectionTitle(this.text, {super.key, this.padding});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: padding ?? const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Row(children:[
        Text(text, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
      ]),
    );
  }
}
