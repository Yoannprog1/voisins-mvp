import 'package:flutter/foundation.dart';

/// Modèle utilisateur local (très simple pour la démo/CI)
class LocalUser {
  final int id;
  final String name;
  final String email; // non-null pour simplifier l'UI
  const LocalUser({required this.id, required this.name, this.email = ''});
}

/// Service d'auth ultra-light : suffit pour compiler/lancer en démo.
class AuthService extends ChangeNotifier {
  LocalUser? _currentUser;

  /// Accès utilisé dans l'app
  LocalUser? get currentUser => _currentUser;

  /// Compatibilité avec certains endroits qui lisaient un String
  String? get current => _currentUser?.id.toString();

  Future<void> init() async {
    // Démarre connecté en mode démo
    _currentUser ??= const LocalUser(id: 1, name: 'Démo', email: 'demo@example.com');
  }

  /// Connexion e-mail/mot de passe. Renvoie `null` si OK ou un message d'erreur.
  Future<String?> login(String email, String password) async {
    // Ici tu mettras ton vrai appel Supabase plus tard
    if (email.isEmpty || password.isEmpty) return 'Email ou mot de passe manquant';
    _currentUser = LocalUser(id: 1, name: email.split('@').first, email: email);
    notifyListeners();
    return null;
  }

  /// Création de compte. Renvoie `null` si OK ou un message.
  Future<String?> signup(String email, String name, String password) async {
    if (email.isEmpty || name.isEmpty || password.isEmpty) return 'Champs requis manquants';
    _currentUser = LocalUser(id: 1, name: name, email: email);
    notifyListeners();
    return null;
  }

  Future<void> logout() async {
    _currentUser = null;
    notifyListeners();
  }
}
