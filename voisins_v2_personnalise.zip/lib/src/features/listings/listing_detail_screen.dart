import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ListingDetailScreen extends StatefulWidget {
  final String id; const ListingDetailScreen({super.key, required this.id});
  @override State<ListingDetailScreen> createState()=>_ListingDetailScreenState();
}
class _ListingDetailScreenState extends State<ListingDetailScreen> {
  Map<String,dynamic>? item;
  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async {
    final data = await Supabase.instance.client.from('listings').select().eq('id', widget.id).maybeSingle();
    setState(()=> item = data);
  }
  @override
  Widget build(BuildContext context) {
    final l = item; if(l==null) return const Center(child:CircularProgressIndicator());
    return Scaffold(appBar: AppBar(title: Text(l['title']??'Annonce')), body: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
      Text('${(l['price']??0).round()} €/${l['unit']??'prestation'}', style: Theme.of(context).textTheme.headlineSmall),
      const SizedBox(height: 8),
      Row(children:[ const Icon(Icons.place_outlined), const SizedBox(width:4), Text(l['city']??''), const SizedBox(width:12), Chip(label: Text(l['category']??'')) ]),
      const SizedBox(height: 12),
      Text(l['description']??''),
      const Spacer(),
      SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: () async {
        // open or create conversation with owner, then go to /chat/:id
        final sb = Supabase.instance.client;
        final me = sb.auth.currentUser!.id;
        final owner = l['owner_id'] as String;
        var convo = await sb.from('conversations').select().or('a_id.eq.$me,b_id.eq.$owner').limit(1).maybeSingle();
        if (convo == null) {
          convo = await sb.from('conversations').insert({'a_id': me, 'b_id': owner}).select().single();
        }
        if (!mounted) return;
        GoRouter.of(context).go('/chat/${convo['id']}');
      }, icon: const Icon(Icons.chat), label: const Text('Contacter')))
    ])));
  }
}
