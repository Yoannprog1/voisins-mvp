import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class CreateListingScreen extends StatefulWidget{ const CreateListingScreen({super.key}); @override State<CreateListingScreen> createState()=>_CreateListingScreenState(); }
class _CreateListingScreenState extends State<CreateListingScreen>{
  final _form=GlobalKey<FormState>();
  final _title=TextEditingController(); final _desc=TextEditingController(); final _price=TextEditingController(); final _city=TextEditingController();
  String _unit='prestation'; String _category='Bricolage';

  @override
  Widget build(BuildContext context){
    return Scaffold(appBar: AppBar(title: const Text('Nouvelle annonce')), body: Padding(padding: const EdgeInsets.all(16), child: Form(key:_form, child: ListView(children:[
      TextFormField(controller:_title, decoration: const InputDecoration(labelText:'Titre'), validator:(v)=> v==null||v.isEmpty?'Obligatoire':null),
      TextFormField(controller:_desc, decoration: const InputDecoration(labelText:'Description')),
      TextFormField(controller:_price, decoration: const InputDecoration(labelText:'Prix'), keyboardType: const TextInputType.numberWithOptions(decimal:true)),
      TextFormField(controller:_city, decoration: const InputDecoration(labelText:'Ville')),
      const SizedBox(height:8),
      DropdownButtonFormField(value:_unit, items: const [DropdownMenuItem(value:'h', child: Text('à l\'heure')), DropdownMenuItem(value:'prestation', child: Text('à la prestation')), DropdownMenuItem(value:'jour', child: Text('à la journée'))], onChanged:(v)=> setState(()=> _unit=v??'prestation'), decoration: const InputDecoration(labelText:'Unité')),
      DropdownButtonFormField(value:_category, items: const [DropdownMenuItem(value:'Bricolage', child: Text('Bricolage')), DropdownMenuItem(value:'Jardinage', child: Text('Jardinage')), DropdownMenuItem(value:'Déménagement', child: Text('Déménagement')), DropdownMenuItem(value:'Informatique', child: Text('Informatique')), DropdownMenuItem(value:'Ménage', child: Text('Ménage'))], onChanged:(v)=> setState(()=> _category=v??'Bricolage'), decoration: const InputDecoration(labelText:'Catégorie')),
      const SizedBox(height:16),
      FilledButton(onPressed: () async {
        if(!_form.currentState!.validate()) return;
        final sb = Supabase.instance.client;
        final me = sb.auth.currentUser!.id;
        await sb.from('listings').insert({'owner_id': me, 'title': _title.text, 'description': _desc.text, 'price': double.tryParse(_price.text)??0, 'unit': _unit, 'city': _city.text, 'category': _category });
        if(mounted) Navigator.pop(context);
      }, child: const Text('Publier'))
    ]))));
  }
}
