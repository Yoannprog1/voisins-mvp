import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ChatScreen extends StatefulWidget{
  final String conversationId; const ChatScreen({super.key, required this.conversationId});
  @override State<ChatScreen> createState()=>_ChatScreenState();
}
class _ChatScreenState extends State<ChatScreen>{
  final _ctrl = TextEditingController();
  List<Map<String,dynamic>> _msgs=[];
  RealtimeChannel? _chan; StreamSubscription<dynamic>? _sub;

  @override void initState(){ super.initState(); _load(); _subscribe(); }
  @override void dispose(){ _chan?.unsubscribe(); _sub?.cancel(); super.dispose(); }

  Future<void> _load() async {
    final data = await Supabase.instance.client.from('messages').select().eq('convo_id', widget.conversationId).order('created_at');
    setState(()=> _msgs=(data as List).cast<Map<String,dynamic>>());
  }

  void _subscribe(){
    final sb = Supabase.instance.client;
    _chan = sb.channel('realtime:messages_${widget.conversationId}')
      .on(PostgresChangeEvent.insert, ChannelFilter(event: '*', schema: 'public', table: 'messages', filter: 'convo_id=eq.${widget.conversationId}'),
        (payload, {ref}) { _load(); })
      .subscribe();
  }

  Future<void> _send() async {
    final text = _ctrl.text.trim(); if (text.isEmpty) return;
    final sb = Supabase.instance.client; final me = sb.auth.currentUser!.id;
    await sb.from('messages').insert({'convo_id': widget.conversationId, 'from_user': me, 'text': text});
    _ctrl.clear();
  }

  @override Widget build(BuildContext context){
    return Scaffold(appBar: AppBar(title: const Text('Chat')), body: Column(children:[
      Expanded(child: ListView.builder(padding: const EdgeInsets.all(12), itemCount:_msgs.length, itemBuilder:(_,i){
        final m=_msgs[i]; final fromMe = m['from_user']==Supabase.instance.client.auth.currentUser?.id;
        return Align(alignment: fromMe? Alignment.centerRight: Alignment.centerLeft, child: Container(
          padding: const EdgeInsets.all(10), margin: const EdgeInsets.symmetric(vertical:4),
          decoration: BoxDecoration(color: fromMe? Colors.blue.shade100: Colors.grey.shade200, borderRadius: BorderRadius.circular(10)),
          child: Text(m['text']??''),
        ));
      })),
      Padding(padding: const EdgeInsets.all(8), child: Row(children:[
        Expanded(child: TextField(controller:_ctrl, decoration: const InputDecoration(hintText:'Votre message'))),
        IconButton(onPressed: _send, icon: const Icon(Icons.send))
      ]))
    ]));
  }
}
