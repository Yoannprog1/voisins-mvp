import 'package:flutter/foundation.dart';

/// Re-implémentation simple pour CI : expose `currentUser` (avec `.id`) et `current` (string).
class LocalUser {
  final int id;
  final String name;
  final String? email;
  const LocalUser({required this.id, this.name = 'Démo', this.email});
}

class AuthService extends ChangeNotifier {
  LocalUser? _currentUser;

  /// Accès utilisé un peu partout dans l'app (attendu par le code existant)
  LocalUser? get currentUser => _currentUser;

  /// Compat’ avec certains écrans qui lisaient `current` (string)
  String? get current => _currentUser?.id.toString();

  Future<void> init() async {
    // Démarrage connecté pour permettre les builds/démos sans auth réelle
    _currentUser ??= const LocalUser(id: 1, name: 'Démo');
  }

  Future<void> signInAnonymously() async {
    _currentUser = const LocalUser(id: 1, name: 'Démo');
    notifyListeners();
  }

  Future<void> signOut() async {
    _currentUser = null;
    notifyListeners();
  }
}
