import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../auth/auth_service.dart';
import 'listing.dart';
import 'listings_repo.dart';

class CreateEditListingScreen extends StatefulWidget {
  const CreateEditListingScreen({super.key});

  @override
  State<CreateEditListingScreen> createState() => _CreateEditListingScreenState();
}

class _CreateEditListingScreenState extends State<CreateEditListingScreen> {
  final _form = GlobalKey<FormState>();
  String _title = '', _desc = '', _city = '', _category = '';
  String _price = '';
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: const Text('Publier une annonce')),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _form,
            child: ListView(
              children: [
                TextFormField(
                  decoration: const InputDecoration(labelText: 'Titre'),
                  validator: (v) => (v == null || v.isEmpty) ? 'Requis' : null,
                  onSaved: (v) => _title = v!.trim(),
                ),
                TextFormField(
                  decoration: const InputDecoration(labelText: 'Description'),
                  maxLines: 3,
                  onSaved: (v) => _desc = v?.trim() ?? '',
                ),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        decoration: const InputDecoration(labelText: 'Ville'),
                        onSaved: (v) => _city = v?.trim() ?? '',
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextFormField(
                        decoration: const InputDecoration(labelText: 'Catégorie'),
                        onSaved: (v) => _category = v?.trim() ?? '',
                      ),
                    ),
                  ],
                ),
                TextFormField(
                  decoration: const InputDecoration(labelText: 'Prix (€)'),
                  keyboardType: TextInputType.number,
                  validator: (v) => (v == null || v.isEmpty) ? 'Requis' : null,
                  onSaved: (v) => _price = v ?? '',
                ),
                const SizedBox(height: 16),
                FilledButton(
                  onPressed: _busy ? null : () async {
                    if (!_form.currentState!.validate()) return;
                    _form.currentState!.save();
                    setState(() => _busy = true);
                    final listing = Listing(
                      id: 0,
                      ownerId: auth.currentUser!.id,
                      title: _title,
                      description: _desc,
                      price: double.tryParse(_price.replaceAll(',', '.')) ?? 0,
                      city: _city,
                      category: _category,
                      createdAt: DateTime.now(),
                    );
                    await ListingsRepo().create(listing);
                    if (context.mounted) Navigator.pop(context);
                  },
                  child: _busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Publier'),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
