# Sprint 0 — Allo Qubic (shell)

Minimal Flutter app avec 5 onglets, prête à être buildée en APK.

## Lancer localement
```
flutter create .
flutter pub get
flutter run
```

## CI GitHub Actions (APK)
Utilise ce workflow simple (à mettre dans `.github/workflows/build.yml`) :

```yaml
name: Build APK
on:
  workflow_dispatch:
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with: { distribution: temurin, java-version: "17" }
      - uses: android-actions/setup-android@v3
      - uses: subosito/flutter-action@v2
        with: { channel: stable, flutter-version: "3.22.2" }
      - name: Ensure Android project exists
        run: |
          if [ ! -f android/app/build.gradle ]; then
            flutter create --platforms=android .
          fi
      - run: flutter pub get
      - run: yes | sdkmanager --licenses
      - run: flutter build apk --debug
      - uses: actions/upload-artifact@v4
        with: { name: app-debug, path: build/app/outputs/flutter-apk/app-debug.apk }
```
