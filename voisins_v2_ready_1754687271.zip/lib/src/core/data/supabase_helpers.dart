import 'package:supabase_flutter/supabase_flutter.dart';
final sb = Supabase.instance.client;

Future<List<Map<String,dynamic>>> simpleFetch(String table) async {
  final data = await sb.from(table).select().order('created_at', ascending: false);
  return (data as List).cast<Map<String, dynamic>>();
}
