import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../features/listings/listings_screen.dart';
import '../features/requests/requests_screen.dart';
import '../features/chat/chat_screen.dart';
import '../features/profile/profile_screen.dart';

final appRouter = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(path: '/', builder: (_, __) => const _HomeTabs()),
    GoRoute(path: '/chat/:id', builder: (_, s) => ChatScreen(conversationId: s.pathParameters['id']!)),
  ],
);

class _HomeTabs extends StatefulWidget {
  const _HomeTabs();
  @override State<_HomeTabs> createState()=>_HomeTabsState();
}
class _HomeTabsState extends State<_HomeTabs>{
  int tab=0;
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: const Text('Voisins')),
      body: IndexedStack(index: tab, children: const [ListingsScreen(), RequestsScreen(), ProfileScreen()]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i)=> setState(()=> tab=i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.storefront_outlined), label: 'Annonces'),
          NavigationDestination(icon: Icon(Icons.assignment_outlined), label: 'Demandes'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profil'),
        ],
      ),
    );
  }
}
