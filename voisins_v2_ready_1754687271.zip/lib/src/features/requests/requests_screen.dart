import 'package:flutter/material.dart';
import '../../core/data/supabase_helpers.dart';

class RequestsScreen extends StatefulWidget{ const RequestsScreen({super.key}); @override State<RequestsScreen> createState()=>_RequestsScreenState(); }
class _RequestsScreenState extends State<RequestsScreen>{
  List<Map<String,dynamic>> items=[];
  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async { items = await simpleFetch('service_requests'); setState((){}); }
  @override Widget build(BuildContext context){
    return RefreshIndicator(onRefresh: _load, child: ListView.builder(padding: const EdgeInsets.all(12), itemCount:items.length, itemBuilder: (_,i){
      final r = items[i];
      return Card(child: ListTile(title: Text(r['title']??''), subtitle: Text(r['city']??'')));
    }));
  }
}
