import 'package:flutter/material.dart';
import '../../core/data/supabase_helpers.dart';

class ListingsScreen extends StatefulWidget{ const ListingsScreen({super.key}); @override State<ListingsScreen> createState()=>_ListingsScreenState(); }
class _ListingsScreenState extends State<ListingsScreen>{
  List<Map<String,dynamic>> items=[];
  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async { items = await simpleFetch('listings'); setState((){}); }
  @override Widget build(BuildContext context){
    return RefreshIndicator(onRefresh: _load, child: ListView.builder(padding: const EdgeInsets.all(12), itemCount:items.length, itemBuilder: (_,i){
      final l = items[i];
      return Card(child: ListTile(title: Text(l['title']??''), subtitle: Text(l['city']??'')));
    }));
  }
}
