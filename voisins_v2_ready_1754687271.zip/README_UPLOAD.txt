Uploader ce ZIP à la racine du repo (branche main) puis lancer le workflow.
