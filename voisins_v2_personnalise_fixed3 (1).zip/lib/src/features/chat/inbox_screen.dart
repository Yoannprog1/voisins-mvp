import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:go_router/go_router.dart';

class InboxScreen extends StatefulWidget{ const InboxScreen({super.key}); @override State<InboxScreen> createState()=>_InboxScreenState(); }
class _InboxScreenState extends State<InboxScreen>{
  List<Map<String,dynamic>> _convos=[];
  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async {
    final sb = Supabase.instance.client;
    final me = sb.auth.currentUser?.id;
    if (me==null) return;
    final data = await sb.from('conversations').select().or('a_id.eq.$me,b_id.eq.$me').order('created_at', ascending:false);
    setState(()=> _convos = (data as List).cast<Map<String,dynamic>>());
  }
  @override Widget build(BuildContext context){
    return RefreshIndicator(onRefresh: _load, child: ListView.builder(padding: const EdgeInsets.all(12), itemCount:_convos.length, itemBuilder: (_,i){
      final c=_convos[i]; return Card(child: ListTile(
        leading: const Icon(Icons.forum_outlined),
        title: Text('Conversation ${c['id'].toString().substring(0,8)}'),
        onTap: ()=> GoRouter.of(context).go('/chat/${c['id']}'),
      ));
    }));
  }
}
