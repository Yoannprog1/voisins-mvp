import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import '../../core/data/supabase_helpers.dart';

class ListingsScreen extends StatefulWidget { const ListingsScreen({super.key}); @override State<ListingsScreen> createState()=>_ListingsScreenState(); }
class _ListingsScreenState extends State<ListingsScreen> {
  final _qCtrl = TextEditingController();
  String _category=''; String _city='';
  List<String> _cats = [];

  @override
  void initState() {
    super.initState();
    _loadCats();
    _refresh();
  }

  Future<void> _loadCats() async {
    final raw = await rootBundle.loadString('assets/app_config.json');
    final j = json.decode(raw);
    setState(()=> _cats = (j['categories'] as List).cast<String>());
  }

  List<Map<String,dynamic>> _items = [];
  Future<void> _refresh() async {
    final data = await fetchWithFilters(table: 'listings', q: _qCtrl.text, category: _category, city: _city);
    setState(()=> _items = data);
  }

  @override
  Widget build(BuildContext context) {
    return Column(children:[
      _Filters(cats:_cats, qCtrl:_qCtrl, onApply:(q,c,city){_category=c; _city=city; _refresh();}),
      Expanded(child: RefreshIndicator(
        onRefresh: _refresh,
        child: ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: _items.length,
          itemBuilder: (_, i){
            final l = _items[i];
            return Card(
              child: ListTile(
                title: Text(l['title']??''),
                subtitle: Text('${l['city']??''} • ${l['category']??''}'),
                trailing: Text('${(l['price']??0).round()} €/${l['unit']??'prestation'}'),
                onTap: ()=> GoRouter.of(context).go('/listing/${l['id']}'),
              ),
            );
          },
        ),
      ))
    ]);
  }
}

class _Filters extends StatelessWidget {
  final List<String> cats; final TextEditingController qCtrl; final void Function(String q, String c, String city) onApply;
  const _Filters({required this.cats, required this.qCtrl, required this.onApply, super.key});
  @override
  Widget build(BuildContext context) {
    String cat=''; String city='';
    return Container(
      padding: const EdgeInsets.fromLTRB(12,8,12,8), decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.grey.shade300))),
      child: Row(children:[
        Expanded(child: TextField(controller:qCtrl, decoration: const InputDecoration(hintText:'Rechercher un service', prefixIcon: Icon(Icons.search)))),
        const SizedBox(width: 8),
        SizedBox(width: 120, child: TextField(decoration: const InputDecoration(hintText:'Ville', prefixIcon: Icon(Icons.place_outlined)), onChanged:(v)=> city=v)),
        const SizedBox(width: 8),
        DropdownButton<String>(value: cat.isEmpty? null: cat, hint: const Text('Catégorie'), items: cats.map((e)=> DropdownMenuItem(value:e, child: Text(e))).toList(), onChanged:(v){ cat = v??''; }),
        const SizedBox(width: 8),
        ElevatedButton(onPressed: ()=> onApply(qCtrl.text, cat, city), child: const Text('Filtrer'))
      ]),
    );
  }
}
