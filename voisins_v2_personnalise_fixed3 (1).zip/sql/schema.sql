-- Minimal schema + RLS for Voisins v2

create extension if not exists pgcrypto;

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  city text,
  bio text,
  avatar_url text,
  rating numeric default 0,
  reviews_count int default 0
);

create table if not exists listings (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references auth.users(id) on delete cascade,
  title text not null,
  description text,
  price numeric not null,
  unit text not null default 'prestation',
  city text,
  category text,
  photos jsonb default '[]'::jsonb,
  rating numeric default 0,
  reviews int default 0,
  created_at timestamp with time zone default now()
);

create table if not exists service_requests (
  id uuid primary key default gen_random_uuid(),
  author_id uuid references auth.users(id) on delete cascade,
  title text not null,
  description text,
  budget numeric,
  city text,
  category text,
  status text default 'open',
  created_at timestamp with time zone default now()
);

create table if not exists conversations (
  id uuid primary key default gen_random_uuid(),
  a_id uuid references auth.users(id) on delete cascade,
  b_id uuid references auth.users(id) on delete cascade,
  created_at timestamp with time zone default now()
);

create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  convo_id uuid references conversations(id) on delete cascade,
  from_user uuid references auth.users(id) on delete cascade,
  text text not null,
  created_at timestamp with time zone default now()
);

create table if not exists offers (
  id uuid primary key default gen_random_uuid(),
  request_id uuid references service_requests(id) on delete cascade,
  by_user uuid references auth.users(id) on delete cascade,
  message text,
  amount numeric,
  status text default 'pending',
  created_at timestamp with time zone default now()
);

-- RLS
alter table profiles enable row level security;
alter table listings enable row level security;
alter table service_requests enable row level security;
alter table conversations enable row level security;
alter table messages enable row level security;
alter table offers enable row level security;

create policy "Public read profiles" on profiles for select using (true);
create policy "Self write profile" on profiles for insert with check (auth.uid() = id);
create policy "Self update profile" on profiles for update using (auth.uid() = id);

create policy "Public read listings" on listings for select using (true);
create policy "Owner manage listing" on listings for insert with check (auth.uid() = owner_id);
create policy "Owner update listing" on listings for update using (auth.uid() = owner_id);

create policy "Public read requests" on service_requests for select using (true);
create policy "Author manage request" on service_requests for insert with check (auth.uid() = author_id);
create policy "Author update request" on service_requests for update using (auth.uid() = author_id);

create policy "Participants read convos" on conversations for select using (a_id = auth.uid() or b_id = auth.uid());
create policy "Create convo including me" on conversations for insert with check (a_id = auth.uid() or b_id = auth.uid());

create policy "Participants read messages" on messages for select using (exists (select 1 from conversations c where c.id = messages.convo_id and (c.a_id = auth.uid() or c.b_id = auth.uid())));
create policy "Send messages as me" on messages for insert with check (from_user = auth.uid());

create policy "Offers visible to author or bidder" on offers for select using (exists (select 1 from service_requests r where r.id = offers.request_id and (r.author_id = auth.uid() or offers.by_user = auth.uid())));
create policy "Create offer as me" on offers for insert with check (by_user = auth.uid());
