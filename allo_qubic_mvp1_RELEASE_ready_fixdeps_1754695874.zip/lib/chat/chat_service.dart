import 'package:sqflite/sqflite.dart';
import '../utils/db.dart';

class ChatService {
  Future<int> ensureThread({required int listingId, required int a, required int b}) async {
    final db = await AppDb.db;
    final rows = await db.query('threads',
        where: 'listing_id = ? AND ((user_a = ? AND user_b = ?) OR (user_a = ? AND user_b = ?))',
        whereArgs: [listingId, a, b, b, a]);
    if (rows.isNotEmpty) return rows.first['id'] as int;
    return db.insert('threads', {
      'listing_id': listingId,
      'user_a': a,
      'user_b': b,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  Future<List<Map<String, dynamic>>> threadsForUser(int userId) async {
    final db = await AppDb.db;
    return db.query('threads',
      where: 'user_a = ? OR user_b = ?',
      whereArgs: [userId, userId],
      orderBy: 'created_at DESC',
    );
  }

  Future<List<Map<String, dynamic>>> messagesForThread(int threadId) async {
    final db = await AppDb.db;
    return db.query('messages',
      where: 'thread_id = ?',
      whereArgs: [threadId],
      orderBy: 'created_at ASC',
    );
  }

  Future<void> sendMessage(int threadId, int senderId, String body) async {
    final db = await AppDb.db;
    await db.insert('messages', {
      'thread_id': threadId,
      'sender_id': senderId,
      'body': body,
      'created_at': DateTime.now().toIso8601String(),
    });
  }
}
