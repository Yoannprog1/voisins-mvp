import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../auth/auth_service.dart';
import 'chat_service.dart';
import 'thread_screen.dart';

class ChatsScreen extends StatefulWidget {
  const ChatsScreen({super.key});

  @override
  State<ChatsScreen> createState() => _ChatsScreenState();
}

class _ChatsScreenState extends State<ChatsScreen> {
  final _svc = ChatService();
  List<Map<String, dynamic>> _threads = [];
  bool _busy = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final user = context.read<AuthService>().currentUser!;
    final t = await _svc.threadsForUser(user.id);
    setState(() { _threads = t; _busy = false; });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: const Text('Messages'), actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh))
        ]),
        body: _busy
          ? const Center(child: CircularProgressIndicator())
          : _threads.isEmpty
            ? const Center(child: Text('Aucune conversation.'))
            : ListView.separated(
                itemBuilder: (_, i){
                  final t = _threads[i];
                  return ListTile(
                    title: Text('Conversation #${t['id']}'),
                    subtitle: Text('Annonce ID: ${t['listing_id']}'),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ThreadScreen(threadId: t['id'] as int))).then((_) => _load()),
                  );
                },
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemCount: _threads.length,
              ),
      ),
    );
  }
}
