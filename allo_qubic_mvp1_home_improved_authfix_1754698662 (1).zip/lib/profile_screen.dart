import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'auth/auth_service.dart';
import 'payment/qubic_payment_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    final u = auth.currentUser!;
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: const Text('Profil')),
        body: ListView(
          children: [
            const SizedBox(height: 16),
            const CircleAvatar(radius: 40, child: Icon(Icons.person, size: 40)),
            const SizedBox(height: 8),
            Center(child: Text(u.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
            Center(child: Text(u.email)),
            const SizedBox(height: 16),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.currency_bitcoin),
              title: const Text('Paiement QUBIC'),
              subtitle: const Text('Configurer l’adresse et tester le deeplink'),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const QubicPaymentScreen())),
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Se déconnecter'),
              onTap: () => auth.logout(),
            ),
          ],
        ),
      ),
    );
  }
}
