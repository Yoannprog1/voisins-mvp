import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../auth/auth_service.dart';
import '../listings/listing.dart';
import '../listings/listings_repo.dart';
import '../listings/listing_detail_screen.dart';
import '../listings/create_edit_listing_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _search = TextEditingController();
  final _repo = ListingsRepo();
  final _chips = <String>{};
  bool _busy = false;
  int _tab = 0; // 0 list, 1 map
  List<Listing> _items = [];

  final _quickFilters = const ['≤ 5 km', 'Ce week-end', 'Vérifiés', 'Moins cher', '4★ et +'];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _busy = true);
    _items = await _repo.all(q: _search.text.trim());
    setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthService>().current;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: TextField(
          controller: _search,
          decoration: const InputDecoration(
            hintText: 'Rechercher un service, ex: Bricolage',
            prefixIcon: Icon(Icons.search),
            border: InputBorder.none,
          ),
          textInputAction: TextInputAction.search,
          onSubmitted: (_) => _load(),
        ),
        actions: [
          IconButton(icon: const Icon(Icons.tune), onPressed: _openFilters),
          IconButton(icon: Icon(_tab==0? Icons.map_outlined: Icons.list_alt), onPressed: ()=> setState(()=> _tab = _tab==0?1:0)),
        ],
      ),
      body: Column(
        children: [
          SizedBox(
            height: 44,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              scrollDirection: Axis.horizontal,
              itemCount: _quickFilters.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) {
                final label = _quickFilters[i];
                final selected = _chips.contains(label);
                return FilterChip(
                  label: Text(label),
                  selected: selected,
                  onSelected: (v){ setState((){ v? _chips.add(label): _chips.remove(label);}); _load(); },
                );
              },
            ),
          ),
          Expanded(
            child: _busy
              ? const Center(child: CircularProgressIndicator())
              : _tab==1
                ? const _MapPlaceholder()
                : _items.isEmpty
                  ? _emptyState(context, user!=null)
                  : RefreshIndicator(
                      onRefresh: _load,
                      child: ListView.separated(
                        padding: const EdgeInsets.all(12),
                        itemCount: _items.length,
                        separatorBuilder: (_, __)=> const SizedBox(height: 8),
                        itemBuilder: (_, i)=> _ListingCard(item: _items[i], onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (_)=> ListingDetailScreen(listing: _items[i])));
                        }),
                      ),
                    ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_)=> const CreateEditListingScreen())).then((_) => _load()),
        icon: const Icon(Icons.add),
        label: const Text('Publier'),
      ),
    );
  }

  Widget _emptyState(BuildContext ctx, bool loggedIn) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Icon(Icons.search_off, size: 64),
            const SizedBox(height: 12),
            const Text('Aucune annonce pour l’instant', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            const Text('Essaye d’élargir le rayon ou change de catégorie.', textAlign: TextAlign.center),
            const SizedBox(height: 16),
            if (loggedIn)
              OutlinedButton.icon(onPressed: _load, icon: const Icon(Icons.refresh), label: const Text('Actualiser'))
            else
              OutlinedButton.icon(onPressed: (){}, icon: const Icon(Icons.login), label: const Text('Se connecter')),
          ],
        ),
      ),
    );
  }

  void _openFilters() {
    showModalBottomSheet(context: context, builder: (ctx){
      String tri = 'Pertinence';
      double rayon = 10;
      return StatefulBuilder(builder: (ctx, setSheet){
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Filtres', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              const Text('Tri'),
              const SizedBox(height: 4),
              DropdownButton<String>(value: tri, items: const [
                DropdownMenuItem(value: 'Pertinence', child: Text('Pertinence')),
                DropdownMenuItem(value: 'Plus proche', child: Text('Plus proche')),
                DropdownMenuItem(value: 'Moins cher', child: Text('Moins cher')),
                DropdownMenuItem(value: 'Mieux noté', child: Text('Mieux noté')),
                DropdownMenuItem(value: 'Nouveautés', child: Text('Nouveautés')),
              ], onChanged: (v)=> setSheet(()=> tri = v ?? 'Pertinence')),
              const SizedBox(height: 12),
              Text('Rayon : ${rayon.toStringAsFixed(0)} km'),
              Slider(min: 1, max: 50, divisions: 49, value: rayon, onChanged: (v)=> setSheet(()=> rayon = v)),
              const SizedBox(height: 12),
              FilledButton.icon(onPressed: (){ Navigator.pop(context); _load(); }, icon: const Icon(Icons.check), label: const Text('Appliquer')),
              const SizedBox(height: 8),
            ],
          ),
        );
      });
    });
  }
}

class _ListingCard extends StatelessWidget {
  final Listing item;
  final VoidCallback onTap;
  const _ListingCard({required this.item, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const CircleAvatar(radius: 28, child: Icon(Icons.handyman)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(child: Text(item.title, style: const TextStyle(fontWeight: FontWeight.w600))),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.blue.withOpacity(.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text('€${item.price.toStringAsFixed(0)}/h'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      item.description,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: Theme.of(context).textTheme.bodySmall?.color),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Icon(Icons.place, size: 16),
                        const SizedBox(width: 4),
                        Text(item.city),
                        const SizedBox(width: 12),
                        const Icon(Icons.calendar_today, size: 16),
                        const SizedBox(width: 4),
                        Text(DateFormat.yMMMd().format(item.createdAt)),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MapPlaceholder extends StatelessWidget {
  const _MapPlaceholder();
  @override
  Widget build(BuildContext context) {
    return const Center(child: Text('Carte à venir'));
  }
}
