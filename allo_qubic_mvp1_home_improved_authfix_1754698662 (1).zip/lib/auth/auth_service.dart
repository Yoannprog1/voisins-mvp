import 'package:flutter/foundation.dart';

/// AuthService minimaliste pour la démo / build CI.
/// Expose un getter `current` pour savoir si l'utilisateur est connecté.
class AuthService extends ChangeNotifier {
  String? _current; // null = déconnecté

  String? get current => _current;

  /// Initialisation (peut restaurer une session si tu en as une)
  Future<void> init() async {
    // Ici on peut restaurer depuis un stockage local.
    // Pour la démo, on démarre connecté.
    _current ??= 'demo_user';
  }

  Future<void> signInAnonymously() async {
    _current = 'demo_user';
    notifyListeners();
  }

  Future<void> signOut() async {
    _current = null;
    notifyListeners();
  }
}
