class Listing {
  final int id;
  final int ownerId;
  final String title;
  final String description;
  final double price;
  final String city;
  final String category;
  final DateTime createdAt;

  Listing({
    required this.id,
    required this.ownerId,
    required this.title,
    required this.description,
    required this.price,
    required this.city,
    required this.category,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'owner_id': ownerId,
    'title': title,
    'description': description,
    'price': price,
    'city': city,
    'category': category,
    'created_at': createdAt.toIso8601String(),
  };

  static Listing fromMap(Map<String, dynamic> m) => Listing(
    id: m['id'],
    ownerId: m['owner_id'],
    title: m['title'],
    description: m['description'],
    price: (m['price'] as num).toDouble(),
    city: m['city'] ?? '',
    category: m['category'] ?? '',
    createdAt: DateTime.parse(m['created_at']),
  );
}
