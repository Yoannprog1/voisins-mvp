# Allo Qubic — MVP1 (fonctionnel, offline)

Fonctionnalités incluses :
- **Auth locale** : inscription / connexion (email + mot de passe) stockées localement.
- **Annonces (CRUD)** : créer, lister, éditer, supprimer. Recherche simple.
- **Messagerie locale** : démarrer une conversation depuis une annonce et échanger des messages (local).
- **Paiement QUBIC (deeplink)** : écran qui construit un lien `qubic://pay?to=...&amount=...&memo=...` et permet de copier l'adresse / ouvrir le wallet (si supporté).

> Pas de backend : tout est **local** (sqflite + shared_preferences). Parfait pour tester les écrans et les parcours.

## Lancer en local
```
flutter create .
flutter pub get
flutter run
```

## Build APK via GitHub Actions
Un workflow est inclus : `.github/workflows/build.yml`.
Dans GitHub → **Actions → Build APK → Run workflow**. L'APK est dans les Artifacts (`app-debug.apk`).

## Roadmap suivante
- Auth OTP / serveur réel (NestJS + Postgres).
- Paiement QUBIC Phase 1 (vérification on-chain).
- Escrow (contrat Qubic C++) & litiges.
